import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";

export const About = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="about" className="snap-section h-screen flex items-center" ref={ref}>
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="grid md:grid-cols-2 gap-16 items-center"
          >
            {/* Left Side - Text Content */}
            <div className="space-y-8">
              <div>
                <motion.span
                  initial={{ opacity: 0 }}
                  animate={isInView ? { opacity: 1 } : {}}
                  transition={{ delay: 0.2 }}
                  className="text-primary text-sm uppercase tracking-wider"
                >
                  About Me
                </motion.span>
                <motion.h2
                  initial={{ opacity: 0, x: -20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ delay: 0.3 }}
                  className="text-5xl md:text-6xl font-bold mt-4 mb-8"
                >
                  Building the{" "}
                  <span className="text-primary">future</span>
                </motion.h2>
              </div>

              <motion.p
                initial={{ opacity: 0 }}
                animate={isInView ? { opacity: 1 } : {}}
                transition={{ delay: 0.4 }}
                className="text-xl text-muted-foreground leading-relaxed"
              >
                Jovem desenvolvedor visionário de Mogi Mirim/SP, fascinado por tecnologia, 
                IA e o universo cyberpunk. Especializado em SecDevOps, projetos de servidores 
                bare metal e sistemas Linux customizados.
              </motion.p>

              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={isInView ? { opacity: 1, scale: 1 } : {}}
                whileHover={{ scale: 1.02, boxShadow: "0 0 30px rgba(255,255,255,0.1)" }}
                transition={{ delay: 0.5 }}
                className="glass p-8 rounded-lg border border-primary/20"
              >
                <blockquote className="text-lg italic text-foreground">
                  "Security isn't a barrier — it's the art of digital precision."
                </blockquote>
                <cite className="text-primary mt-4 block not-italic">— Tarcys Amorim</cite>
              </motion.div>
            </div>

            {/* Right Side - Timeline */}
            <motion.div
              initial={{ opacity: 0, x: 40 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ delay: 0.6 }}
              className="space-y-8"
            >
              <div className="space-y-6">
                {[
                  {
                    year: "2023",
                    title: "SecDevOps Specialist",
                    description: "Advanced security implementations and DevOps workflows"
                  },
                  {
                    year: "2022",
                    title: "Full-Stack Development",
                    description: "Enterprise web applications with React, Node.js, and PostgreSQL"
                  },
                  {
                    year: "2021",
                    title: "Cybersecurity Focus",
                    description: "Deep dive into penetration testing and security architecture"
                  },
                  {
                    year: "2020",
                    title: "Linux & Systems",
                    description: "Custom kernel development and bare metal server management"
                  }
                ].map((item, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: 20 }}
                    animate={isInView ? { opacity: 1, x: 0 } : {}}
                    transition={{ delay: 0.7 + index * 0.1 }}
                    className="relative pl-8 border-l-2 border-primary/30 hover:border-primary transition-colors duration-300"
                  >
                    <div className="absolute -left-2 top-0 w-4 h-4 rounded-full bg-primary" />
                    <span className="text-primary text-sm font-semibold">{item.year}</span>
                    <h3 className="text-xl font-bold mt-1 mb-2">{item.title}</h3>
                    <p className="text-muted-foreground">{item.description}</p>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
