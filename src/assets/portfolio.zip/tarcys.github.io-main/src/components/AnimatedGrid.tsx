import { motion } from "framer-motion";

export const AnimatedGrid = () => {
  return (
    <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
      {/* Animated lines */}
      {Array.from({ length: 20 }).map((_, i) => (
        <motion.div
          key={`v-${i}`}
          className="absolute h-full w-px bg-primary/5"
          style={{ left: `${(i + 1) * 5}%` }}
          initial={{ scaleY: 0, opacity: 0 }}
          animate={{ 
            scaleY: 1, 
            opacity: [0.1, 0.3, 0.1],
          }}
          transition={{
            scaleY: { duration: 2, delay: i * 0.1 },
            opacity: { duration: 3, repeat: Infinity, delay: i * 0.2 }
          }}
        />
      ))}
      
      {Array.from({ length: 20 }).map((_, i) => (
        <motion.div
          key={`h-${i}`}
          className="absolute w-full h-px bg-primary/5"
          style={{ top: `${(i + 1) * 5}%` }}
          initial={{ scaleX: 0, opacity: 0 }}
          animate={{ 
            scaleX: 1, 
            opacity: [0.1, 0.3, 0.1],
          }}
          transition={{
            scaleX: { duration: 2, delay: i * 0.1 },
            opacity: { duration: 3, repeat: Infinity, delay: i * 0.2 }
          }}
        />
      ))}

      {/* Floating orbs */}
      {Array.from({ length: 5 }).map((_, i) => (
        <motion.div
          key={`orb-${i}`}
          className="absolute w-64 h-64 rounded-full bg-primary/5 blur-3xl"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
          }}
          animate={{
            x: [0, Math.random() * 100 - 50, 0],
            y: [0, Math.random() * 100 - 50, 0],
            scale: [1, 1.2, 1],
            opacity: [0.1, 0.3, 0.1],
          }}
          transition={{
            duration: 10 + i * 2,
            repeat: Infinity,
            ease: "easeInOut",
            delay: i * 2,
          }}
        />
      ))}
    </div>
  );
};
