import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef, useState } from "react";
import { ExternalLink, Github } from "lucide-react";
import projectSecurity from "@/assets/project-security.jpg";
import projectFullstack from "@/assets/project-fullstack.jpg";
import projectAI from "@/assets/project-ai.jpg";

const projects = [
  {
    title: "Bare Metal OS Project",
    description: "Custom operating system kernel built from scratch with Limine bootloader. Features include memory management, process scheduling, and custom filesystem implementation.",
    image: projectSecurity,
    stack: ["C", "Assembly", "Limine", "UEFI"],
    link: "#",
    github: "#"
  },
  {
    title: "Sulamericana Full-Stack Platform",
    description: "Enterprise web application with real-time data processing, user authentication, and responsive design. Built for scalability and performance.",
    image: projectFullstack,
    stack: ["React", "Node.js", "PostgreSQL", "Tailwind"],
    link: "#",
    github: "#"
  },
  {
    title: "AI Local Assistant",
    description: "Python-based AI assistant with complete system control, natural language processing, and machine learning capabilities for task automation.",
    image: projectAI,
    stack: ["Python", "TensorFlow", "NLP", "API Integration"],
    link: "#",
    github: "#"
  }
];

export const Projects = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  return (
    <section id="projects" className="snap-section h-screen flex items-center overflow-y-auto" ref={ref}>
      <div className="container mx-auto px-6 py-20">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="max-w-7xl mx-auto"
        >
          {/* Header */}
          <div className="mb-20">
            <motion.span
              initial={{ opacity: 0 }}
              animate={isInView ? { opacity: 1 } : {}}
              transition={{ delay: 0.2 }}
              className="text-primary text-sm uppercase tracking-wider"
            >
              Selected Work
            </motion.span>
            <motion.h2
              initial={{ opacity: 0, x: -20 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ delay: 0.3 }}
              className="text-5xl md:text-6xl font-bold mt-4"
            >
              Featured <span className="text-primary">Projects</span>
            </motion.h2>
          </div>

          {/* Projects Grid */}
          <div className="space-y-20">
            {projects.map((project, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 60 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: 0.4 + index * 0.2, duration: 0.8 }}
                className="group"
                onMouseEnter={() => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
              >
                <div className={`grid md:grid-cols-2 gap-12 items-center ${index % 2 === 1 ? 'md:grid-flow-dense' : ''}`}>
                  {/* Image */}
                  <motion.div
                    className={`relative overflow-hidden rounded-lg ${index % 2 === 1 ? 'md:col-start-2' : ''}`}
                    whileHover={{ scale: 1.02 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="relative aspect-video overflow-hidden rounded-lg border border-primary/20">
                      <img
                        src={project.image}
                        alt={project.title}
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent opacity-60" />
                      
                      {/* Hover Overlay */}
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: hoveredIndex === index ? 1 : 0 }}
                        className="absolute inset-0 bg-primary/10 backdrop-blur-sm flex items-center justify-center gap-4"
                      >
                        <motion.a
                          href={project.link}
                          whileHover={{ scale: 1.1 }}
                          className="p-4 bg-background rounded-full border border-primary"
                        >
                          <ExternalLink className="w-6 h-6 text-primary" />
                        </motion.a>
                        <motion.a
                          href={project.github}
                          whileHover={{ scale: 1.1 }}
                          className="p-4 bg-background rounded-full border border-primary"
                        >
                          <Github className="w-6 h-6 text-primary" />
                        </motion.a>
                      </motion.div>
                    </div>
                  </motion.div>

                  {/* Content */}
                  <motion.div 
                    className={`space-y-6 ${index % 2 === 1 ? 'md:col-start-1 md:row-start-1' : ''}`}
                    initial={{ opacity: 0, x: index % 2 === 0 ? -60 : 60 }}
                    animate={isInView ? { opacity: 1, x: 0 } : {}}
                    transition={{ delay: 0.5 + index * 0.1, duration: 0.8 }}
                  >
                    <div>
                      <span className="text-primary text-sm font-mono">0{index + 1}</span>
                      <h3 className="text-3xl md:text-4xl font-bold mt-2 mb-4 group-hover:text-primary transition-all duration-300">
                        {project.title}
                      </h3>
                      <p className="text-lg text-muted-foreground leading-relaxed">
                        {project.description}
                      </p>
                    </div>

                    {/* Stack */}
                    <div className="flex flex-wrap gap-3">
                      {project.stack.map((tech, i) => (
                        <motion.span
                          key={i}
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={isInView ? { opacity: 1, scale: 1 } : {}}
                          transition={{ delay: 0.6 + index * 0.2 + i * 0.05 }}
                          className="px-4 py-2 text-sm font-mono bg-muted/50 border border-primary/20 rounded-lg hover:border-primary transition-colors duration-300"
                        >
                          {tech}
                        </motion.span>
                      ))}
                    </div>
                  </motion.div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};
