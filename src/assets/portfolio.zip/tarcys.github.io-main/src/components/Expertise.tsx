import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { Code, Shield, Database, Server, Terminal, Cpu } from "lucide-react";

const skills = [
  { name: "Python", icon: Code, level: 95 },
  { name: "JavaScript/TS", icon: Code, level: 90 },
  { name: "React", icon: Code, level: 92 },
  { name: "Node.js", icon: Server, level: 88 },
  { name: "Cybersecurity", icon: Shield, level: 93 },
  { name: "Linux/Unix", icon: Terminal, level: 96 },
  { name: "PostgreSQL", icon: Database, level: 85 },
  { name: "System Design", icon: Cpu, level: 90 }
];

export const Expertise = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="expertise" className="snap-section h-screen flex items-center" ref={ref}>
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="max-w-6xl mx-auto"
        >
          {/* Header */}
          <div className="mb-20 text-center">
            <motion.span
              initial={{ opacity: 0 }}
              animate={isInView ? { opacity: 1 } : {}}
              transition={{ delay: 0.2 }}
              className="text-primary text-sm uppercase tracking-wider"
            >
              Technical Arsenal
            </motion.span>
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.3 }}
              className="text-5xl md:text-6xl font-bold mt-4"
            >
              Skills & <span className="text-primary">Expertise</span>
            </motion.h2>
          </div>

          {/* Stats Counter */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ delay: 0.4 }}
            className="glass p-12 rounded-lg mb-20 text-center"
          >
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div>
                <motion.div
                  initial={{ scale: 0 }}
                  animate={isInView ? { scale: 1 } : {}}
                  transition={{ delay: 0.5, type: "spring" }}
                  className="text-5xl font-bold text-primary mb-2"
                >
                  4+
                </motion.div>
                <div className="text-muted-foreground">Years Experience</div>
              </div>
              <div>
                <motion.div
                  initial={{ scale: 0 }}
                  animate={isInView ? { scale: 1 } : {}}
                  transition={{ delay: 0.6, type: "spring" }}
                  className="text-5xl font-bold text-primary mb-2"
                >
                  50+
                </motion.div>
                <div className="text-muted-foreground">Projects Completed</div>
              </div>
              <div>
                <motion.div
                  initial={{ scale: 0 }}
                  animate={isInView ? { scale: 1 } : {}}
                  transition={{ delay: 0.7, type: "spring" }}
                  className="text-5xl font-bold text-primary mb-2"
                >
                  15+
                </motion.div>
                <div className="text-muted-foreground">Technologies Mastered</div>
              </div>
            </div>
          </motion.div>

          {/* Skills Grid */}
          <div className="grid md:grid-cols-2 gap-8">
            {skills.map((skill, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -40 : 40 }}
                animate={isInView ? { opacity: 1, x: 0 } : {}}
                whileHover={{ 
                  scale: 1.05, 
                  y: -5,
                  transition: { duration: 0.2 }
                }}
                transition={{ delay: 0.5 + index * 0.1, duration: 0.6 }}
                className="group"
              >
                <div className="glass p-6 rounded-lg hover:border-primary transition-all duration-300">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="p-3 rounded-lg bg-primary/10 group-hover:bg-primary/20 transition-colors duration-300">
                      <skill.icon className="w-6 h-6 text-primary" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold">{skill.name}</h3>
                    </div>
                    <span className="text-primary font-mono text-sm">{skill.level}%</span>
                  </div>
                  
                  {/* Progress Bar */}
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={isInView ? { width: `${skill.level}%` } : {}}
                      transition={{ delay: 0.7 + index * 0.1, duration: 1, ease: "easeOut" }}
                      className="h-full bg-primary"
                    />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};
