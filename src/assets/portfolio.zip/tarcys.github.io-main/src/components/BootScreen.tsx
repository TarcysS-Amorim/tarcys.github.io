import { motion } from "framer-motion";
import { useEffect, useState } from "react";

interface BootScreenProps {
  onComplete: () => void;
}

export const BootScreen = ({ onComplete }: BootScreenProps) => {
  const [progress, setProgress] = useState(0);
  
  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(onComplete, 500);
          return 100;
        }
        return prev + 2;
      });
    }, 30);
    
    return () => clearInterval(interval);
  }, [onComplete]);

  const bootMessages = [
    "Initializing secure kernel...",
    "Loading cybersecurity protocols...",
    "Mounting encrypted filesystems...",
    "Starting network interfaces...",
    "Deploying defense systems...",
    "System ready."
  ];

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-background flex flex-col items-center justify-center font-mono"
    >
      <div className="max-w-2xl w-full px-8 space-y-8">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="space-y-2"
        >
          <div className="text-primary text-sm mb-8">TARCYS_OS v3.14.2</div>
          
          {bootMessages.map((msg, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0 }}
              animate={{ opacity: progress > (i * 16.6) ? 1 : 0 }}
              className="text-muted-foreground text-xs"
            >
              <span className="text-primary">[OK]</span> {msg}
            </motion.div>
          ))}
        </motion.div>

        <div className="space-y-2">
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>Loading system...</span>
            <span>{progress}%</span>
          </div>
          <div className="h-1 bg-muted rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-primary to-secondary"
              initial={{ width: "0%" }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.1 }}
            />
          </div>
        </div>
      </div>
    </motion.div>
  );
};
