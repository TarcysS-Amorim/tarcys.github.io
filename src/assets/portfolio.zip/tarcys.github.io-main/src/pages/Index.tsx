import { useState, useEffect } from "react";
import { AnimatePresence } from "framer-motion";
import { BootScreen } from "@/components/BootScreen";
import { Navigation } from "@/components/Navigation";
import { Hero } from "@/components/Hero";
import { About } from "@/components/About";
import { Projects } from "@/components/Projects";
import { Expertise } from "@/components/Expertise";
import { Contact } from "@/components/Contact";
import { CustomCursor } from "@/components/CustomCursor";
import { Scene3D } from "@/components/Scene3D";
import { AnimatedGrid } from "@/components/AnimatedGrid";
import { PageTransition } from "@/components/PageTransition";

const Index = () => {
  const [showBoot, setShowBoot] = useState(true);

  useEffect(() => {
    // Check if boot screen was already shown
    const bootShown = sessionStorage.getItem("bootShown");
    if (bootShown) {
      setShowBoot(false);
    }
  }, []);

  const handleBootComplete = () => {
    sessionStorage.setItem("bootShown", "true");
    setShowBoot(false);
  };

  return (
    <>
      <AnimatePresence>
        {showBoot && <BootScreen onComplete={handleBootComplete} />}
      </AnimatePresence>

      {!showBoot && (
        <PageTransition>
          <div className="relative">
            <CustomCursor />
            <Scene3D />
            <AnimatedGrid />
            <Navigation />
            <main>
              <Hero />
              <About />
              <Projects />
              <Expertise />
              <Contact />
            </main>
          </div>
        </PageTransition>
      )}
    </>
  );
};

export default Index;
