# tarcys.github.io

Projeto Vite + React (TypeScript) com componentes shadcn/ui e Three.js.

Rápido resumo de como rodar localmente:

1. Instalar dependências (se ainda não instalou):

```powershell
npm install
```

2. Rodar em modo desenvolvimento (Vite):

```powershell
npm run dev
# Abra http://localhost:8081/ ou a porta informada pelo terminal
```

3. Build de produção:

```powershell
npm run build
```

4. Servir build local (preview):

```powershell
npm run preview
# Abra http://localhost:4173/ ou a porta informada pelo terminal
```

Notas:
- O projeto usa Vite; a porta pode mudar se a padrão estiver em uso.
- Se precisar, rode `npm run build` seguido de `npm run preview` para testar a versão otimizada.

Se quiser, eu posso commitar estas mudanças, rodar mais verificações ou configurar scripts adicionais.
